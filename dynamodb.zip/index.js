/* This skill can send SMS using the Amazon SNS service to any of the contacts saved by the user.
 * The Contact is saved in DynamoDB and persistence is maintained that way. */
'use strict';
var Alexa           = require('alexa-sdk');
var Handlers        = require('./Handlers.js');
var contactHandlers = require('./Contacts.js');
var GooglePhoneBook = require('./GooglePhoneBook.js');


exports.handler = function(event, context, callback) {
  var alexa = Alexa.handler(event, context);
  var appId = "amzn1.ask.skill.7894e981-07dc-47c2-919d-5164b788b650";   //"amzn1.ask.skill.538b73ec-8d62-4589-865f-7946e29fb855";
  alexa.APP_ID = appId;
  alexa.dynamoDBTableName = "geolocationInternProjectTable";
  alexa.registerHandlers(Handlers, GooglePhoneBook);
  alexa.execute();
};

