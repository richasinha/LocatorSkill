'use strict';
var EntryService   = require('./EntryService.js');
var Intents        = require('./Intents.js');
var Messages       = require('./Messages.js');
var phoneHelper    = require('./PhoneHelper.js');

const SMSMyLocation = function() {
  var alexa        = this;
  var service      = new EntryService();
  var name         = this.event.request.intent.slots.Name.value;
  var consentToken = true; //Needs to be changed to the permission

  if(!consentToken){
    alexa.emit(":tell",Messages.NO_PERMISSION);
    return;
  }
  /* The below will be changed to this.event.context.Geolocation.coordinates.latitudeInDegrees + ','
   * + this.event.context.Geolocation.coordinates.longitudeInDegrees;
   */

  if(this.attributes['myName'] == undefined) {
    alexa.emit(":tell",Messages.ASK_NAME);
    return;
  }

  var location = '';
  if(this.event.context.Geolocation == undefined) {
    location = '47.616678,-122.335286';
    console.log("No geolocation context");
  } else {
    var latitude = this.event.context.Geolocation.coordinates.latitudeInDegrees;
    var longitude = this.event.context.Geolocation.coordinates.longitudeInDegrees;
    location = latitude + ',' + longitude;
  }

  service.read(this.event.session.user.userId, function(err, data) {
    if(!err){
      if(data.Item == undefined) {
        alexa.emit(":tell",Messages.NO_CONTACT_SAVED);
        return;
      }
      var phoneMap = data.Item.phoneMap;
      var found = phoneHelper.ifContactExists(phoneMap, name);
      var toSMS = (found[0] == true) ? phoneMap[found[1]].phone : '';
      if(toSMS == '') {
        alexa.emit(":tell", Messages.NO_CONTACT_FOR_NAME + name);
        return;
      }      
      phoneHelper.sendMessage(location, alexa, toSMS, name, function(err, resp) {
        if (err) 
          alexa.emit(":tell",Messages.NO_SMS_SENT + name +'.');
        else 
          alexa.emit(":tell",Messages.SMS_SENT + name + '.');
      });
    } else {
    alexa.emit(":tell",Messages.ERROR + Messages.ERROR_GET_CONTACT);
   }    
  });
};

/* intent SaveMyFriendsPhone: Used to save the contact */
const SaveMyFriendsPhone = function() {
  var alexa    = this;
  var userId   = this.event.session.user.userId;
  var service  = new EntryService();
  var intent   = this.event.request.intent;
  var name     = intent.slots.Name.value;

  if(intent.slots.phoneNum.value.length != 10) {
    alexa.emit(":tell", Messages.INVALID_PHONE_NUMBER);
    return;
  } else {
    service.read(userId, function(err, data) {
      var phoneNum = '+1'+alexa.event.request.intent.slots.phoneNum.value;
      if(data.Item == undefined) { //If there is no contact in the directory, create one
        service.create(userId, name, phoneNum, function(err, data) {
          if(err) {
            console.log(err);
            alexa.emit(":tell",Messages.NO_SAVE + name + '.');
          } else {
            alexa.emit(":tell",Messages.CONTACT_SAVED + name + '.');
          }
        });
      } else {
        var phoneMap = data.Item.phoneMap;
        var found = phoneHelper.ifContactExists(phoneMap, name);
        var toSMS = (found[0] == true) ? phoneMap[found[1]].phone : '';
        if(toSMS == '') { //The number of friend does not exist, hence add it to the list
          service.append(userId, name, phoneNum, function(err, data) {
            if(err) {
              alexa.emit(":tell",Messages.NO_SAVE + name + '.');
            } else {
              alexa.emit(":tell",Messages.CONTACT_SAVED + name + '.');
            }
          });
        } else {
          var msg = Messages.CONTACT_PRESENT(name, toSMS);
          alexa.emit(":ask", msg);
        }
      }
    });
  }
};

/* intent updateMyFriendsContact: Used to update the phone number of an already saved contact in the DynamoDB. */
const updateMyFriendsContact = function() {
  var alexa    = this;
  var service  = new EntryService();
  var intent   = this.event.request.intent;
  var name     = intent.slots.Name.value;
  var phoneNum = '+1'+intent.slots.phoneNum.value;
  var userId   = this.event.session.user.userId;

  service.read(userId, function(err, data) {
    if(data.Item == undefined) {
      alexa.emit(":tell",Messages.NO_CONTACT_SAVED);
    } else {
      var phoneMap = data.Item.phoneMap;
      var found = phoneHelper.ifContactExists(phoneMap, name);
      if(found[0] == true) {
        service.delete(userId, found[1], function(err, data) {
          if (err) {
            console.log("Error in deletion while updating");
            alexa.emit(":tell",Messages.NO_UPDATE + name + '.');
          } else {
            service.append(userId, name, phoneNum, function(err, data) {
              if(err) {
                console.log(err);
                alexa.emit(":tell",Messages.NO_UPDATE + name + '.');
              } else {
                var msg = Messages.UPDATE_SUCCESSFUL(name, phoneNum)
                alexa.emit(":tell",msg);
              }
            });
          }
        });
      } else {
        alexa.emit(":tell", Messages.ERROR + Messages.ERROR_GET_CONTACT + name + '.');
      }
    }
  });
};

/* intent deleteMyFriendsContact: Used to delete the phone number of an already saved contact in the DynamoDB.*/
const deleteMyFriendsContact = function() {
  var alexa    = this;
  var service  = new EntryService();
  var intent   = this.event.request.intent;
  var name     = intent.slots.Name.value;
  var userId   = this.event.session.user.userId;

  service.read(userId, function(err, data) {
    if(data.Item == undefined) {
        alexa.emit(":tell",Messages.NO_CONTACT_SAVED);
    } else {
      var phoneMap = data.Item.phoneMap;
      var found = phoneHelper.ifContactExists(phoneMap, name);
      if(found[0] == true) {
        service.delete(userId, found[1], function(err, data) {
          if (err) {
            alexa.emit(":tell",Messages.NO_DELETE + name + '.');
          } else {
            alexa.emit(":tell",Messages.DELETE_SUCCESSFUL + name + '.');
          }
        });
      } else {
        alexa.emit(":tell", Messages.ERROR_GET_CONTACT + name);
      }
    }
  });
};

const contactHandlers = {};

contactHandlers[Intents.SEND_MY_LOCATION] = SMSMyLocation;
contactHandlers[Intents.SAVE_CONTACT]     = SaveMyFriendsPhone;
contactHandlers[Intents.UPDATE_CONTACT]   = updateMyFriendsContact;
contactHandlers[Intents.DELETE_CONTACT]   = deleteMyFriendsContact;

module.exports = contactHandlers;