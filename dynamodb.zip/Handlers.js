'use strict';

const Intents = require('./Intents.js');
const Messages = require('./Messages.js');

const amazonCancelHandler = function() {
    this.emit(":tell", Messages.GOODBYE);
    console.info("Ending CacnelHandler");
};

const amazonStopHandler = function() {
    this.emit(":tell", Messages.GOODBYE);
    console.info("Ending Stop Handler");
};

const amazonHelpHandler = function() {
    this.emit(":tell", Messages.HELP);
};

const amazonLaunchHandler = function() {
    var msg = Messages.WELCOME;
    msg += "What would you like to do?";
    this.emit(":ask", msg, msg);
};

const amazonUnhandledHandler = function() {
    this.emit(":ask", Messages.UNHANDLED, Messages.UNHANDLED);
};

const amazonNewSessionHandler = function() {
    if (this.event.request.type === Intents.LAUNCH_REQUEST) {
        this.emit(Intents.LAUNCH_REQUEST);
    } else if (this.event.request.type === "IntentRequest") {
        this.emit(this.event.request.intent.name);
    }
};

const sessionEndedHandler = function() {
    this.emit(":tell", Messages.GOODBYE);
    console.info("Ending session Handler");
};

/* intent saveMyName: Used to save the name of the user in the DynamoDB. */
const saveMyName = function() {
    this.attributes['myName'] = this.event.request.intent.slots.Name.value;
    this.emit(":tell", "Hi " + this.attributes['myName'] + "! Please save your contacts.");
};


const handlers = {};

handlers[Intents.LAUNCH_REQUEST] = amazonLaunchHandler;
handlers[Intents.UNHANDLED] = amazonUnhandledHandler;
handlers[Intents.AMAZON_CANCEL] = amazonCancelHandler;
handlers[Intents.AMAZON_STOP] = amazonStopHandler;
handlers[Intents.AMAZON_HELP] = amazonHelpHandler;
handlers[Intents.NEW_SESSION] = amazonNewSessionHandler;
handlers[Intents.SESSION_ENDED] = sessionEndedHandler;
handlers[Intents.SAVE_MY_NAME] = saveMyName;

module.exports = handlers;