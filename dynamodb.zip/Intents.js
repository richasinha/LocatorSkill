'use strict';

/**
 * Your skill will receive a NewSession event when a
 * session has been started on your skill. An example of this would be
 * when a user says "open skill blah blah blah".
 */
const NEW_SESSION = "NewSession";

/**
 * Your service receives a LaunchRequest when the user invokes the skill with the
 * invocation name, but does not provide any command mapping to an intent.
 * Refer to the following URL for documentation:
 * https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/handling-requests-sent-by-alexa#launchrequest
 */
const LAUNCH_REQUEST = "LaunchRequest";

/**
 * Your service receives a SessionEndedRequest when a currently open session is closed.
 * https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/handling-requests-sent-by-alexa#sessionendedrequest
 */
const SESSION_ENDED = "SessionEndedRequest";

/**
 * Your skill will receive an Unhandled event when it receives an intent that
 * it has not registered for.
 */
const UNHANDLED = "Unhandled";

/* This is an Amazon built-in intent.*/
const AMAZON_HELP = "AMAZON.HelpIntent";

/* This is an Amazon built-in intent.*/
const AMAZON_CANCEL = "AMAZON.CancelIntent";

/* This is an Amazon built-in intent.*/
const AMAZON_STOP = "AMAZON.StopIntent";

/* The below is to send location via SMS */
const SEND_MY_LOCATION = "SMSMyLocation";

/* The below intent is to save the contact */
const SAVE_CONTACT = "SaveMyFriendsPhone";

/* The below intent is to update the contact */
const UPDATE_CONTACT = "updateMyFriendsContact";

/* The below intent is to save the name of the user */
const SAVE_MY_NAME = "saveMyName";

/* The below intent is to delete the contact */
const DELETE_CONTACT = "deleteMyFriendsContact";


module.exports = {
    "NEW_SESSION": NEW_SESSION,
    "LAUNCH_REQUEST": LAUNCH_REQUEST,
    "SESSION_ENDED": SESSION_ENDED,
    "UNHANDLED": UNHANDLED,
    "AMAZON_HELP": AMAZON_HELP,
    "AMAZON_CANCEL": AMAZON_CANCEL,
    "AMAZON_STOP": AMAZON_STOP,
    "SEND_MY_LOCATION": SEND_MY_LOCATION,
    "SAVE_CONTACT": SAVE_CONTACT,
    "UPDATE_CONTACT": UPDATE_CONTACT,
    "SAVE_MY_NAME": SAVE_MY_NAME,
    "DELETE_CONTACT": DELETE_CONTACT
};